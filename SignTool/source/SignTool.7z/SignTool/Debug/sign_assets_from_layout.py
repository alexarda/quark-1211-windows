
import configparser
import os
import subprocess
import sys

# Configuration
SIGN_EXE = "sign.exe"
KEY_FILE = "private.pem"
OUTPUT_DIR = "signed_output"

# Ensure output directory exists
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

# Read layout.conf using ConfigParser in INI mode
config = configparser.ConfigParser(strict=False)
config.optionxform = str  # Preserve case
config.read("layout.conf")

# Iterate over sections
for section in config.sections():
    options = config[section]

    sign = options.get("sign", "").lower()
    if sign != "yes":
        continue  # Skip items not marked for signing

    input_file = options.get("item_file")
    svn_index = options.get("svn_index", "0")
    svn = "1"  # Default SVN, could be read from metadata later

    if not input_file or not os.path.isfile(input_file):
        print(f"[WARNING] Skipping {section}: invalid or missing file: {input_file}")
        continue

    input_filename = os.path.basename(input_file)
    output_file = os.path.join(OUTPUT_DIR, input_filename + ".signed")

    cmd = [
        SIGN_EXE,
        "-i", input_file,
        "-k", KEY_FILE,
        "-s", svn,
        "-x", svn_index,
        "-o", output_file
    ]

    print(f"[INFO] Signing {input_file} -> {output_file}")
    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.returncode != 0:
        print(f"[ERROR] Failed to sign {input_file}")
        print(result.stderr)
    else:
        print(f"[OK] Signed: {output_file}")
